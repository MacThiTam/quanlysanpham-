<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class k3controller extends Controller
{
    //
}
