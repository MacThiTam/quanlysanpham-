<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    //
    public function index(){
        $product_sum = DB::table('products')->count('id');
        //dd($product_sum);
        return view('admin/page.home',['$product_sum'=>$product_sum]);
    }
}
