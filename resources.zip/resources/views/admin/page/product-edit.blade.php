@extends('admin/layouts.index')
@section('title')
Thanh Tâm Bakery Administrator
@endsection
@section('content')
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
                <li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
                <li><a href="">Quản lý sản phẩm</a></li>
            <li class="active">Sửa sản phẩm </li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Sản phẩm: Sản phẩm  </h1>
			</div>
        </div><!--/.row-->
        <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="col-md-6">
                                <form  action="/admin/updateProduct" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="id" value="{{$product->id}}">
                                    <div class="form-group">
                                    <label>Tên sản phẩm</label>
                                    <input required name="prd_name" class="form-control" value="{{$product->name}}" placeholder="">
                                </div>
                                                                
                                <div class="form-group">
                                    <label>Giá sản phẩm</label>
                                <input required name="prd_price" value="{{$product->price}}" class="form-control">
                                </div>                   
                                <div class="form-group">
                                    <label>Khuyến mãi</label>
                                <input required name="prd_promotion" type="text" value="{{$product->discount}}" class="form-control">
                                </div>  
                                {{-- <div class="form-group">
                                    <label>Tình trạng</label>
                                    <input  name="prd_new" type="text" class="form-control">
                                </div>   --}}
                                
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Ảnh sản phẩm</label>
                                    <input required name="prd_image" type="file" value="{{$product->image_link}}">
                                   
                                </div>
                                
                                
                                <div class="form-group">
                                    <label>Danh mục</label>
                                    
                                    <select name="prd_category" class="form-control">
                                        @foreach ($categoryListView as $key=>$row)
                                        @php
                                        if($row->id == $product->category_id){
                                            $selected = "selected";
                                        }
                                        else{
                                            $selected = "";
                                        }
                                        //$selected = ($row->id == $product->category_id) ? "selected" : "";    
                                        @endphp
                                        <option value="{{$row->id}}" {{$selected}}>{{$row->name}}</option>
                                        @endforeach
                                    </select> 
                                </div>   
                            
                    
                                
                                <div class="form-group">
                                    <label>Trạng thái</label>
                                    <select name="prd_status" class="form-control">
                                        @foreach ($statusView as $key=>$row)
                                        @php
                                        if($row->id == $product->status_id){
                                            $selected = "selected";
                                        }
                                        else{
                                            $selected = "";
                                        }
                                        <option value="{{$row->id}}">{{$row->status}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label>Sản phẩm nổi bật</label>
                                    <div class="checkbox">
                                        <label>
                                            <input name="prd_featured" type="checkbox" value=1>Nổi bật
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                        <label>Mô tả sản phẩm</label>
                                        <textarea required name="prd_details" class="form-control" rows="3"></textarea>
                                    </div>
                                <button name="sbm" type="submit" class="btn btn-success">Cập nhật</button>
                                <button type="reset" class="btn btn-default">Làm mới</button>
                            </div>
                        </form>
                        </div>
                    </div>
                </div><!-- /.col-->
            </div><!-- /.row -->
		
	</div>	<!--/.main-->	

