<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
class ProductController extends Controller
{
    //
    public function index(){

        // $listProductDB=DB::table('products');
        //    dd($listProductDB);
        $listProductDB = DB::table('products')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->join('status','products.status_id','=','status.id')
            ->select('products.*', 'categories.name as category','status.status as status')
            ->paginate(12);
          return view('admin/page.product',['productListView'=>$listProductDB]);
        
    }
    public function addproduct(){
        $listCategoryDB = DB::table('categories')->get();
        $status = DB::table('status')->get();
        //dd($listCategoryDB);
        return view('admin/page.product-add', ['categoryListView' => $listCategoryDB,'statusList' => $status]);
        
       // return view('admin/page.product-add', ['statusList' => $status]);


    }
    public function insertProduct(Request $req){
        $image = $req->file('prd_image');
        $name = time() . '.' . $image->getClientOriginalExtension();
        $destinationPath = public_path('/images');
        $image->move($destinationPath, $name);
        DB::table('products')->insert(
            ['name' => $req->prd_name,
            'price'=>$req->prd_price,
            'discount'=>$req->prd_promotion,
            'content'=>$req->prd_details,
            'category_id'=>$req->prd_category,  
            'highlight'=>$req->prd_highlight,
            'image_link' => $name,
            "status_id" => $req->prd_status
            ]
        );
        return redirect('admin/product');

    }
    public function edit($id){
        //dd($id);
        $product = DB::table('products')->find($id);
        $categoryListView = DB::table('categories')->get();
        $status=DB::table('status')->get();
        return view('admin/page.product-edit',
            [
                'product'=>$product,
                'categoryListView'=> $categoryListView,
                'statusView'=>$status
            ]);
        
    }

    public function update(Request $request){
        //dd($request->id);
        DB::table('products')->where('id', $request->id)->update([
            'name' => $request->prd_name,
            'price'=>$request->prd_price,
            'discount'=>$request->prd_promotion,
            'content'=>$request->prd_details,
            'category_id'=>$request->prd_category,
            'image_link' => ''
        ]);
        return redirect('admin/product');
    }
    public function destroy($id){
        $deleteProduct = DB::table('products')->where('id', '=', $id)->delete();
        
        return redirect('admin/product');
    }

}
