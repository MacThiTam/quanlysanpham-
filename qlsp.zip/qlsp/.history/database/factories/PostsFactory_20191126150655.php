<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */
use App\Model;
use Faker\Generator as Faker;

$factory->define(App\Posts::class, function (Faker $faker) {
    return [
            'title' => 'pppppppppp',
            'content' => 'oooooooooo',
            'created_at' => '2019-01-01',
            'updated_at' => '2019-02-02',
    ];
});
