<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UsersController extends Controller
{
    public function index(){
        $listUserDB=DB::table('users')->paginate(5);
        return view('admin/page.user',['userListView'=>$listUserDB]);
    }
    public function store(Request $request){
        $user = new User();

        $user->username = $request->uname;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->save();
        echo 'đăng kí thành công ';
    }
    public function listUser(){
        //$user = DB::table('users')->get();
        return view('register');
    }
    public function postAuthLogin(Request $req){
        $arr=[
            'username'=> $req->uname,
            'password'=> $req->psw

        ];
        if(Auth::attempt($arr)){

        }
        else{
            
        }
    }
}
