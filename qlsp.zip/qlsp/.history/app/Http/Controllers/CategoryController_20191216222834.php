<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;


class CategoryController extends Controller
{
    //
    public function index(){

        $listCategoryDB=DB::table('categories')->paginate(12);
        //dd($categoryListView);
        return view('admin/page.category', ['categoryListView' => $listCategoryDB]);
        //dd($listViewCategory);
    }
    public function addcategory(){
        return view('admin/page.category-add');
    }
    public function insertCategory(Request $req){
        DB::table('Categories')->insert(
            ['name'=>$req->cat_name]
        );
        return redirect('admin/category');

    }
    public function edit($id)
    {
        //dd($id);
        $category = DB::table('categories')->find($id);
        return view('admin/page.category-edit', ['category' => $category]);
    }
    public function update(Request $request)
    {
        //dd($request->id);
        DB::table('categories')->where('id', $request->id)->update([
            'name' => $request->cat_name
        ]);
        return redirect('admin/category');
    }
    public function destroy($id)
    {
        $deleteProduct = DB::table('categories')->where('id', '=', $id)->delete();

        return redirect('admin/category');
    }
}
