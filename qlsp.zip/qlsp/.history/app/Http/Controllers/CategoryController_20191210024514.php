<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    //
    public function index(){
        $listViewCategory=DB::table('categories')->paginate(10);
        return view('admin/category');
    }
}
