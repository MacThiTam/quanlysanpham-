<script src="{{ asset('/admin/js/jquery-1.11.1.min.js') }}"></script>
<script src="{{ asset('/admin/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('/admin/js/bootstrap-table.js') }}"></script>