<?php

namespace App\Http\Composers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class MenuComposer
{
    protected $getSlug = [];
    public function getSlug()
    {
        $this->$getSlug = $slug = DB::table('categories')->get();
        
    }
    public function compose(View $view){

    }
}
