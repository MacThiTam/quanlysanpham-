<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class EnduserController extends Controller
{
    public function index(){
        $listProductDB = DB::table('products')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->select('products.*', 'categories.name as category')
            ->paginate(12);
        return view('page.home', ['productListView' => $listProductDB]);
    }
    public function getListOfCategory(Request $request){
        view("page.category");
    }
}
