<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    //
    public function index(){
        
        $categoryListView=DB::table('categories')->paginate(5);
        //dd($categoryListView);
        return view('admin/page.category');
        //dd($listViewCategory);
    }
}
