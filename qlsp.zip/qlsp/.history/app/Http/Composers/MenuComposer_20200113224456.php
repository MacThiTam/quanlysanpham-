<?php

namespace App\Http\Composers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MenuComposer
{
    protected $getSlug = [];
    public function getSlug()
    {
        $this->getSlug = DB::table('categories')->get();
        
    }
    public function compose(View $view){
        $view->with("getSlug",$this->getSlug);
    }
}
