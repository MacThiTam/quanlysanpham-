<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    //
    public function index(){

        $listCategoryDB=DB::table('categories')->paginate(12);
        //dd($categoryListView);
        return view('admin/page.category', ['categoryListView' => $listProductDB]);
        //dd($listViewCategory);
    }
}
