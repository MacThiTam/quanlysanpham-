<?php


namespace App\Models;
use Illuminate\Database\Eloquent\Models;

class Admin extends Models
{
    //
}
