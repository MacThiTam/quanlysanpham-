<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SearchController extends Controller
{
    //
    public function search(){
        $_GET['search']
        //$data=$req->search1;
        //dd($data);

    }
}
