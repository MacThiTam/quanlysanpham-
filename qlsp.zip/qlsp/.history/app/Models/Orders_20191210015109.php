<?php


namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    //
    protected $table = 'orders';
    protected $fillable = [
        'status','user_id','username','usermail','total_price','message','deliver_id',
    ];

}
