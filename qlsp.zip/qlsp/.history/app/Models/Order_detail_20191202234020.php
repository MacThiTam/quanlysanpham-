<?php


namespace App\Models;
use Illuminate\Database\Eloquent\Models;

class Order_detail extends Models
{
    //
}
