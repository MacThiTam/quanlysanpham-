<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    //
    public function index(){

        $listCategoryDB=DB::table('categories')->paginate(12);
        //dd($categoryListView);
        return view('admin/page.category', ['categoryListView' => $listCategoryDB]);
        //dd($listViewCategory);
    }
    public function addcategory(){
        return view('admin/page.category-add');
    }
    public function insertCategory(Request $req){
        DB::table('Categories')->insert(
            ['name'=>$req->cat_name]
        );
        return view('admin/category');

    }
}
