<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    //
    public function index(){
       $data= $_GET['search'];
        //dd($data);
        $dataDBDB::table('products')->get();

    }
}
