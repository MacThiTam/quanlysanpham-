@extends('admin/layouts.index')
@section('title')
Thanh Tâm Bakery Administrator
@endsection
@section('content')
<!--Body-->
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Danh sách sản phẩm</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Danh sách sản phẩm</h1>
			</div>
		</div><!--/.row-->
		<div id="toolbar" class="btn-group">
            <a href="product-add" class="btn btn-success">
                <i class="glyphicon glyphicon-plus"></i> Thêm sản phẩm
            </a>
           
        </div>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-body">
                        <table 
                            data-toolbar="#toolbar"
                            data-toggle="table">

						    <thead>
						    <tr>
						        <th data-field="id" data-sortable="true">ID</th>
                                <th data-field="name"  data-sortable="true">TÊN</th>
                                <th>DANH MỤC</th>
                                <th>HÌNH ẢNH</th>
                                <th data-field="price" data-sortable="true">GIÁ</th>
                                <th>NỔI BẬT</th>
                                <th>MÔ Tả</th>
                                <th>TRẠNG THÁI</th>
                                <th>HÀNH ĐỘNG</th>
						    </tr>
                            </thead>
                            <tbody>
                                @foreach ($productListView as $key=>$row)
                                    <tr>
                                        <td scope="row">{{$key +1}}</td>
                                        <td>{{$row->name}}</td>
                                        <td>{{$row->category}}</td>
                                        <td><img src="{{asset('images/'.$row->image_link)}}" style="with:50px;height:50px"alt=""></td>
                                        <td>{{$row->price}}</td>
                                        <td>{{$row->highlight == 1 ? 'Có' : 'Không'}}</td>
                                         <td>{{$row->content}}</td>
                                    <td><span class="label label-danger">{{$row->status}}</span></td>
                                       
                                        <td class="form-group">
                                            <a href="product-edit/{{$row->id}}" class="btn btn-primary"><i class="glyphicon glyphicon-pencil"></i></a>
                                            <a href="product-delete/{{$row->id}}" class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                             </tbody>
                             
                        </table>
                        
                    </div>
                    {{$productListView->links()}}
				</div>
			</div>
		</div><!--/.row-->	
    </div>	<!--/.main-->
@endsection
    
