<div id="footer-top">
    <div class="container">
        <div class="row">
            <div id="logo-2" class="col-lg-3 col-md-6 col-sm-12">
                <h2><a href="#"><a href="/"><img class="img-fluid" src="{{ asset('/assets/images/logo.png') }}"
                                style="width:50px;height: 50px;"></a></h1></h2>
                <p>
                    Thanh Tâm Bakery thành lập năm 2019. Chúng tôi chuyên cung cấp các loại bánh ngọt cao cấp phục vụ cho mọi yêu cầu của khách hàng.
                </p>
            </div>
            <div id="address" class="col-lg-3 col-md-6 col-sm-12">
                <h3>Địa chỉ</h3>
                <p>KTX B13 Đại học Bách khoa Hà Nội - Bách Khoa Hai Bà Trưng - Hà Nội</p>
            </div>
            <div id="service" class="col-lg-3 col-md-6 col-sm-12">
                <h3>Dịch vụ</h3>
                <p>Cung cấp mọi loại bánh ngọt trên phạm vi toàn quốc</p>
                <p>Giao hàng tận nơi cho khách hàng</p>
            </div>
            <div id="hotline" class="col-lg-3 col-md-6 col-sm-12">
                <h3>Hotline</h3>
                <p>Phone Sale: 0344370701</p>
                <p>Email: mactam.97@gmail.com</p>
            </div>
        </div>
    </div>
</div>

<!--	Footer	-->
<div id="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <p>
                    2019 © Thanh Tâm Bakery. All rights reserved. Developed by Thanh Tâm Bakery.
                </p>
            </div>
        </div>
    </div>
</div>
<!--	End Footer	-->
{{-- javascript --}}
<script src="{{ asset('/assets/js/jquery-3.3.1.js') }}"></script>
<script src="{{ asset('/assets/js/bootstrap.js') }}"></script>