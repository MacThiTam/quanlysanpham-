<div id="menu">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01"
            aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="/">TRANG CHỦ</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">BÁNH NGỌT</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                        @foreach ($getSlug as $key=>$row)
                            <li><a class="dropdown-item" href="/category/{{$row->slug}}">{{$row->name}}</a></li>
                            
                        @endforeach
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">DẠY LÀM BÁNH NGON</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                        <li><a class="dropdown-item" href="#">Hướng dẫn làm bánh ngon</a></li>
                        <li><a class="dropdown-item" href="#">Hướng dẫn làm đồ uống</a></li>
                        <li><a class="dropdown-item" href="#">Mẹo vặt</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">LIÊN HỆ</a>
                </li>

            </ul>
        </div>
    </nav>
</div>