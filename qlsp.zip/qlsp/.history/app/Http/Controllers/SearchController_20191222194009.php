<?php

namespace App\Http\Controllers;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
class SearchController extends Controller
{
   public function index(){
       $word=$_GET['search'];
        $words = array();
        for ($i = 0; $i < strlen($word); $i++) {
            // insertions
            $words[] = substr($word, 0, $i) . '_' . substr($word, $i);
            // deletions
            $words[] = substr($word, 0, $i) . substr($word, $i + 1);
            // substitutions
            $words[] = substr($word, 0, $i) . '_' . substr($word, $i + 1);
        }
        // last insertion
        $words[] = $word . '_';
        //return $words;
        //dd($words);
        //$sql=DB::table('products')->ge
        //dd($sql);
        foreach ($words as $key) {
            // dd($key);
            $data = DB::table('products')->select('products.name')
                ->where('name', 'like', '%' . $key . '%')->get();
        }
         dd($data);
     //dd( $query);
      //$sql = rtrim($sql, ' OR');
        //dd($sql);
        // $result =$sql->result();
        //return $result;
       //dd($result);
    
   }

}
















//     public function index(){
//     $input= $_GET['search'];
//         // $dataDB  = array(
//         //     'apple', 'pineapple', 'banana', 'orange',
//         //     'radish', 'carrot', 'pea', 'bean', 'potato'
//         // );
//         //dd($dataDB);
//        // dd($data);
//         $dataDB=DB::table('products')->get();
//         //$dataDB->name;
//         //dd($dataDB);
//        //dd($dataDB);
//         //$dataDBDB=json_encode($dataDB);
 
//         //$arr=(array)$dataDB;
//         //dd($arr);
//         //(json_decode($dataDB, true);
//         //dd($dataDBDB);
//         // $lev = levenshtein($input, $dataDB);
//         // dd($lev);
//        // $shortest = -1;
// // //         // loop through words to find the closest
// foreach ($dataDB as $row) {
//           $arr = (array) $row;
//            // dd($arr);
//         [$keys, $values] = Arr::divide($arr);
//         //dd([$values]);
// //foreach($arr as $key=>$col){
// //     dd($col);
 


//  //dd($arr);
// // // // //     // calculate the distance between the input word,
// // // // //     // and the current word
//  $lev = levenshtein($input, $values);
// }
// dd($lev);
// // // //     check for an exact match
// //     if ($lev == 0) {

// //         // closest word is this one (exact match)
// //         $closest = $row;
// //         $shortest = 0;

// //         // break out of the loop; we've found an exact match
// //         break;
// //     }

// //     // if this distance is less than the next found shortest
// //     // distance, OR if a next shortest word has not yet been found
// //     if ($lev <= $shortest || $shortest < 0) {
// //         // set the closest match, and shortest distance
// //         $closest  = $row;
// //         $shortest = $lev;
// //     }
// // }
// // // echo "Input word: $input\n";
// // // if ($shortest == 0) {
// // //     echo "Exact match found: $closest\n";
// // // } else {
// // //     echo "Did you mean: $closest?\n";
// // // }
// // dd($closest);
//    }

