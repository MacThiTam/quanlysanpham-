@extends('layouts.index')
@section('title')
Search
@endsection
@section('content')
<!--	Body	-->
<div id="body">
    <div class="container">
        @include('layouts.menu')
        <div class="row">
            <div id="main" class="col-lg-8 col-md-12 col-sm-12">
                @include('layouts.slide')
                    <!--	List Product	-->
                <div class="products">
                <h4>Kết quả tìm kiếm: {{$count_data}} sản phẩm</h4>
                    <div class="product-list card-deck">
                            @foreach ($data as $row)
                            <div class ="product-item card text-center">
                                <a href="#"><img src="{{asset('images/'.$row->image_link)}}"></a>
                                <h4><a href="#">{{$row->name}}</a></h4>
                                <p>Giá Bán: <span>{{$row->price}}</span></p>
                            </div>
                        @endforeach
                    </div>
                </div>    <!--	End List Product	-->
            </div>
            @include('layouts.sidebar1')
        </div>
   </div>
</div>
@endsection
</html>                
    <!--	End Body	-->
    