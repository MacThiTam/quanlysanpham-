<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class EnduserController extends Controller
{
    public function index(){
        $listProductDB = DB::table('products')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->select('products.*', 'categories.name as category')
            ->paginate(6);
        return view('page.home', ['productListView' => $listProductDB]);
    }
    public function getListOfCategory(Request $request){
        $category = DB::table('categories')
                            ->where('slug', $request->category)
                            ->select('id','name','slug')->first();
        //dd($category);
        $listProductDB = DB::table('products')
            ->where('category_id',$category->id)
            ->get();
        return view("page.category", compact(['category', 'listProductDB']));
    }
    // public function getCategory(){
    //     $slug=DB::table('categories')->get();
    //     return view('page.home',['getSlug'=>$slug]);
    // }
    public function productdetail(Request $req){
        $productview=DB::table('products')->get();
        //dd($productview);
        return view('page.product',['productdetail'=>$productview]);

    }
    
}
