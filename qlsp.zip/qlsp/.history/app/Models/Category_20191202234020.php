<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Models;

class Category extends Models
{
    //
}
