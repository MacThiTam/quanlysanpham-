@extends('admin/layouts.index')
@section('title')
Thanh Tâm Bakery Administrator
@endsection
@section('content')
<!--Body-->
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Quản lý danh mục</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Quản lý danh mục</h1>
			</div>
		</div><!--/.row-->
		<div id="toolbar" class="btn-group">
            <a href="category-add" class="btn btn-success">
                <i class="glyphicon glyphicon-plus"></i> Thêm danh mục
            </a>
        </div>
        <div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-body">
                        <table 
                            data-toolbar="#toolbar"
                            data-toggle="table">

						    <thead>
						    <tr>
						        <th data-field="id" data-sortable="true">ID</th>
                                <th data-field="name"  data-sortable="true">TÊN</th>
                                <th>HÀNH ĐỘNG</th>
						    </tr>
                            </thead>
                            <tbody>
                                @foreach ($categoryListView as $key=>$row)
                                    <tr>
                                        <td scope="row">{{$key +1}}</td>
                                        <td>{{$row->name}}</td>
                                        <td class="form-group">
                                            <a href="category-edit/{{$row->id}}" class="btn btn-primary"><i class="glyphicon glyphicon-pencil"></i></a>
                                            <a href="category-delete/{{$row->id}}" class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                             </tbody>
                             
                        </table>
                        
                    </div>
                    {{$categoryListView->links()}}
				</div>
			</div>
		</div><!--/.row-->	
    </div>	<!--/.main-->
@endsection