<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;

$factory->define(App\Product::class, function (Faker $faker) {
    return [
        'name'=>'AKHKD',
            'price'=>'1938593',
            'created_at' => '2019-01-01',
            'updated_at' => '2019-02-02',
        //
    ];
});
