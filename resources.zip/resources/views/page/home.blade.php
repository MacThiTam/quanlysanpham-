@extends('layouts.index')
@section('title')
Home
@endsection
@section('content')
<!--	Body	-->
<div id="body">
	<div class="container">
        @include('layouts.menu')
            <div class="row">
                <div id="main" class="col-lg-8 col-md-12 col-sm-12">
                    @include('layouts.slide')
                    <!--	Feature Product	-->
                    <div class="products">
                        <h3>Sản phẩm</h3>
                        <div class="product-list card-deck">
                            {{-- @dump($productListView) --}}
                            @foreach ($productListView as $row)
                            <div class="product-item card text-center">
                                <a href="/product/{{$row->id}}"><img src="{{asset('images/'.$row->image_link)}}"></a>
                                <h4><a href="/product/{{$row->id}}">{{$row->name}}</a></h4>
                                <p>Giá Bán: <span>{{$row->price}}</span></p>
                                <p>Giảm giá: {{$row->discount}}</p>
                                <a href="/product/{{$row->id}}" class="button">Chi tiết</a>
                            </div>
                            @endforeach
                        </div>
                    </div> 
                    
                    
                </div>
                
                @include('layouts.sidebar1')
            </div>
            {{$productListView->links()}}
    </div>
</div>
@endsection
</html>
