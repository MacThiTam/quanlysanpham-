<!DOCTYPE html>
    <html>
    @include('admin/layouts.headers')
    <body>
    @include('admin/layouts.menus')
    @yield('content')
    </body>
    @include('admin/layouts.footer')
    </html>