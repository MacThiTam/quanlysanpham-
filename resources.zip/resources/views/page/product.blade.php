@extends('layouts.index')
@section('title')
Product
@endsection
@section('content')
<!--	Body	-->
<div id="body">
	<div class="container">
        @include('layouts.menu')
    	<div class="row">
        	<div id="main" class="col-lg-8 col-md-12 col-sm-12">
            	
            	<!--	Slider	-->
                @include('layouts.slide')
                <!--	End Slider	-->
                
                <!--	List Product	-->
                <div id="product">
                	<div id="product-head" class="row">
                    	<div id="product-img" class="col-lg-6 col-md-6 col-sm-12">
                            @foreach ($productdetail as $row)
                                
                            
                        	<img src="{{asset('images/'.$row->image_link)}}">
                        </div>
                        <div id="product-details" class="col-lg-6 col-md-6 col-sm-12">
                        <h1>{{$row->name}}</h1>
                            <ul>
                                <li><span>Mã: </span>{{$row->id}}</li>
                            <li><span>Khuyến Mại: </span>{{$row->discount}}</li>
                            <li><span>Giá: </span>{{$row->price}}</li>
                            
                            @endforeach
                            @foreach ($statusView as $key=>$row)
                                    <li><span>Tình trạng: </span> {{$row->status}}</li>
                                @endforeach
                             </ul>
                            <div id="add-cart"><a href="#">Mua ngay</a></div>
                        </div>
                    </div>
                    
                    <div id="product-body" class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                             @foreach ($productdetail as $row)
                            <h4>Mô tả:</h4><br><p>{{$row->content}}</p>
                            @endforeach
                        </div>
                    </div>
                    
                    <!--	Comment	-->
                    <div id="comment" class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <h3>Bình luận sản phẩm</h3>
                            <form method="post">
                                <div class="form-group">
                                    <label>Tên:</label>
                                    <input name="comm_name" required type="text" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Email:</label>
                                    <input name="comm_mail" required type="email" class="form-control" id="pwd">
                                </div>
                                <div class="form-group">
                                    <label>Nội dung:</label>
                                    <textarea name="comm_details" required rows="8" class="form-control"></textarea>     
                                </div>
                                <button type="submit" name="sbm" class="btn btn-primary">Gửi</button>
                            </form> 
                        </div>
                    </div>
                    <!--	End Comment	-->  
                    
                    
                </div>
                <!--	End Product	--> 
                             
            </div>
            @include('layouts.sidebar1')
    	</div>
    </div>
    
</div>
@endsection
</html>
