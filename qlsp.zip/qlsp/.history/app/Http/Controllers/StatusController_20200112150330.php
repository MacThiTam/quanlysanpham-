<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class StatusController extends Controller
{
    public function index(){
        $status=DB::table('status')->get();
        return view('admin/page.product-add', ['statusList' => $status]);


    }
}
