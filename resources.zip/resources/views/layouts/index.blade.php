    <!DOCTYPE html>
    <html>

    @include('layouts.headers')
    @yield('content')
    @include('layouts.footer')
    </body>

    </html>
