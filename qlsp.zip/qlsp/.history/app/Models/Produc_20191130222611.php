<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produc extends Model
{
    //
}
