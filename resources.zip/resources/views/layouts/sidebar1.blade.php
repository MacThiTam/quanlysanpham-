<div id="sidebar" class="col-lg-4 col-md-12 col-sm-12">
        <div id="banner">
            <div class="banner-item">
                <a href="/"><img class="img-fluid" src="{{ asset('/assets/images/banner3.jpg') }}"></a>
            </div>
            <div class="banner-item">
                <a href="/"><img class="img-fluid" src="{{ asset('/assets/images/banner1.jpg') }}"></a>
            </div>
            <div class="banner-item">
                <a href="/"><img class="img-fluid" src="{{ asset('/assets/images/banner2.jpg') }}"></a>
            </div>
        </div>
    </div>