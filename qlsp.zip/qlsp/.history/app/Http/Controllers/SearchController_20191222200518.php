<?php

namespace App\Http\Controllers;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
class SearchController extends Controller
{
   public function index(){
       $word=$_GET['search'];
        $words = array();
        for ($i = 0; $i < strlen($word); $i++) {
            // insertions
            $words[] = substr($word, 0, $i) . '_' . substr($word, $i);
            // deletions
            $words[] = substr($word, 0, $i) . substr($word, $i + 1);
            // substitutions
            $words[] = substr($word, 0, $i) . '_' . substr($word, $i + 1);
        }
        $words[] = $word . '_';
        //return $words;
        //dd($words);
        //$sql=DB::table('products')->ge
        //dd($sql);
        foreach ($words as $key) {
            // dd($key);
           // " title LIKE '%" . $regex . "%' OR ";
            $data = DB::table('products')->select('products.name')
                ->where('name', 'like','%'.$key.'%','OR')->get();
        }
        $data= rtrim($data,'OR');
         dd($data);
     
    
   }

}












