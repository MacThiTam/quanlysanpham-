<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class k3controller extends Controller
{
    public function index(){
        return view('k3');
    }
    public function postLogin(Request $req){
        $username=$req->username;
        $password=$req->password;
        return 'xin chào'.$username.'password'.$password;
    }
}
