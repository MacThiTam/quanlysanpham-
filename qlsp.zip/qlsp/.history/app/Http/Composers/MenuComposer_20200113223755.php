<?php

namespace App\Http\Composers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class MenuComposer
{
    //
    public function getSlug()
    {
        $slug = DB::table('categories')->get();
        return view('page.home', ['getSlug' => $slug]);
    }
}
