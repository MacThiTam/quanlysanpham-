@extends('layouts.index')
@section('title')
Category
@endsection
@section('content')
<!--	Body	-->
<div id="body">
	<div class="container">
    	@include('layouts.menu')
        <div class="row">
        	<div id="main" class="col-lg-8 col-md-12 col-sm-12">
            	<!--	Slider	-->
                @include('layouts.slide')
                <!--	End Slider	-->
                
                <!--	List Product	-->
                <div class="products">
                    <h3>{{$category->name}}</h3>
                    <div class="product-list card-deck">
                        @foreach ($listProductDB as $key=>$row)
                            <div class="product-item card text-center">
                                <a href="/product/{{$row->id}}"><img src="{{asset('images/'.$row->image_link)}}"></a>
                                <h4><a href="/product/{{$row->id}}">{{$row->name}}</a></h4>
                                <p>Giá Bán: <span>{{$row->price}}</span></p>
                                <p>Giảm giá: {{$row->discount}}</p>
                                <a href="/product/{{$row->id}}" class="button">Chi tiết</a>
                            </div>
                        @endforeach
                    </div>
                </div>
                <!--	End List Product	-->                
            </div>
            @include('layouts.sidebar1')
        </div>
        {{$listProductDB->links()}}
    </div>
</div>
@endsection
</html>
